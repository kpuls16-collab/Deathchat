package com.example.deathchat.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.gui.screens.DeathScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

// Targets Screen (which declares keyPressed) and only acts when the screen is a DeathScreen.
// DeathScreen itself does not declare keyPressed, so targeting it directly crashes on launch.
@Mixin(Screen.class)
public class DeathScreenMixin {
    private static boolean deathChatEnabled = false;

    @Inject(method = "keyPressed", at = @At("HEAD"), cancellable = true)
    private void deathchat$keyPressed(KeyEvent event, CallbackInfoReturnable<Boolean> cir) {
        if (!((Object) this instanceof DeathScreen)) return;

        Minecraft mc = Minecraft.getInstance();

        if (event.key() == GLFW.GLFW_KEY_LEFT_CONTROL) {
            deathChatEnabled = !deathChatEnabled;
            mc.gui.setOverlayMessage(
                Component.literal("Death chat: " + (deathChatEnabled ? "ON" : "OFF")), false);
            cir.setReturnValue(true);
            return;
        }

        if (!deathChatEnabled) return;

        if (mc.options.keyChat.matches(event)) {
            mc.setScreen(new ChatScreen("", false));
            cir.setReturnValue(true);
        } else if (mc.options.keyCommand.matches(event)) {
            mc.setScreen(new ChatScreen("/", false));
            cir.setReturnValue(true);
        }
    }
}
